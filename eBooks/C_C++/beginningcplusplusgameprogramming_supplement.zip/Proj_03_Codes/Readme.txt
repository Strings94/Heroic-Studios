Chapter 12 to chapter 17 code snippets are provided chapter wish.
Runnable Games are full working games.