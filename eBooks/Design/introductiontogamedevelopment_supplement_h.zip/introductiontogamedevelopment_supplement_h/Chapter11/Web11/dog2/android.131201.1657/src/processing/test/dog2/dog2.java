package processing.test.dog2;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class dog2 extends PApplet {

/* @pjs preload="dog400.jpg"; */
// Sample - Puzzle game Dog
//                                               (C) 2013 MinkHollow Media
// Shuffle puzzle: Dog image is presented, shuffled into
// random blocks and the complete target image. Player must
// move the shuffled blocks so they match the final fescue image.

PImage dogImage;
PImage puzzle[][] = new PImage[5][5];
int pmap[][] = new int[5][5];
int newWidth = 80;
int newHeight = 80;
boolean armed = false;
int armi, armj;
int timer = 0;
int state = 0;
int clicks = 0;

public void setup ()
{
  int i,j, ni, nj, k;
  PImage tmp;
  
// Read the dog image.
  dogImage = loadImage ("dog400.jpg");
  
// There will be 2 images up/down, so the height of the window
// is twice the image width.
//  size (480, 800);   // Remove comment on this line for Java

// Create a 2D array of sub-images.
  for (i=0; i<5; i++)
    for (j=0; j<5; j++)
    {
      puzzle[i][j] = createImage (newWidth, newHeight, RGB);
      puzzle[i][j].copy (dogImage, i*newWidth, j*newHeight, newWidth, newHeight,
                            0, 0, newWidth, newHeight);
      pmap[i][j] = i*5+j;
    }

// Shuffle the sub-images
  for (i=0; i<5; i++)
  {
    for (j=0; j<5; j++)
    {
      ni = (int)random (5); nj = (int)random(5);  // Shuffle to this cell.
      tmp = puzzle[ni][nj];                       // Swap puzzle image cell
      puzzle[ni][nj] = puzzle[i][j];
      puzzle[i][j] = tmp;
      
      k = pmap[ni][nj];                                // Swap position indices
      pmap[ni][nj] = pmap[i][j];
      pmap[i][j] = k;
    }
  } 
  frameRate (5);
  mousePressed();
}

public void draw ()
{
  switch (state)
  {
    case 0: state0();  break;
    case 1: state1();  break;
    case 2: state2 (); break;
  }
}

public void state0 ()
{
    int i=0,j;
 
    image (dogImage, 0, dogImage.height);        // Display the target image
  
// Display the puzzle images, which are smaller and shuffled subimages
  for (i=0; i<5; i++)
    for (j=0; j<5; j++)
      image (puzzle[i][j], i*newWidth, j*newHeight);
}

public void state1 ()
{
  int i,j;
  
 
  image (dogImage, 0, dogImage.height);        // Display the target image
  
// Display the puzzle images, which are smaller and shuffled subimages
  for (i=0; i<5; i++)
    for (j=0; j<5; j++)
      image (puzzle[i][j], i*newWidth, j*newHeight);
  
  if (armed)      // Draw source subimage
  {
    fill(0, 200, 200, 100);
    rect (armi*80, armj*80, 80, 80);
  }
  
  stroke (255);
  strokeWeight (1);
  for (i=0; i<5; i++) 
  {
    line (i*80, 0, i*80, 400);
    line (0, i*80, 400, i*80);
  }
  strokeWeight (3);
  line (399, 0, 399, 400);
  
  for (i=0; i<5; i++)
    for (j=0; j<5; j++)
      if (pmap[i][j] != i*5+j)
      {
        fill (255, 0, 0);
        ellipse (i*80+40, j*80+40, 3, 3);
      }
      
   timer = timer + 1;
   fill (200);  noStroke();
   rect (410, 0, 50, 30);
   fill (0);
   text ("Time: "+timer/5, 410, 30);
}

public void mousePressed ()
{
  int i,j, k;
  PImage tmp;
  
  if (state == 0) 
  {
    state=1; return;
  }
  
  if (state==1)
  {
  i = (int)(mouseX/newWidth);    // Which square was clicked in?
  j = (int)(mouseY/newHeight);
//  println ("Clicked on square "+i+","+j);
  
  if (armed)            // A square has already been selected - swap.
  {
    if (armi == i && armj == j)   // Reset
    {
      armed = false;
//      println ("Disarming.");
    }
    else                          // Swap
    {
      tmp = puzzle[i][j];
      puzzle[i][j] = puzzle[armi][armj];
      puzzle[armi][armj] = tmp;
      k = pmap[i][j];
      pmap[i][j] = pmap[armi][armj];
      pmap[armi][armj] = k;
      armed = false;
      clicks += 1;
    }
  } else                // select a first square for a swap
  {
    armed = true;
    armi = i; armj = j;
  }
  
    if (puzzleSolved()) state = 2;
  }
  
}

public boolean puzzleSolved ()
{
  int i,j,k=0;
  
  for (i=0; i<5; i++)
    for (j=0; j<5; j++)
    {
      if (pmap[i][j] != i*5+j) k++;
    }
   if (k == 0) return true;
   return false;  
}

public void state2()
{
  background (100, 155, 10);
  image (dogImage, 30, 400);
  fill (255);
  text ("Game Over ...  Succcess!", 100, 70);
  text ("This game took you "+timer/10+ " seconds", 50, 200);
  text (" and "+clicks+" moves.", 60, 220);
  text ("Game provided by Dr. J. Parker of MinkHollow Media Ltd.", 50, 300);
  text (" For the book Game Development using Processing", 80, 320);
}


}
