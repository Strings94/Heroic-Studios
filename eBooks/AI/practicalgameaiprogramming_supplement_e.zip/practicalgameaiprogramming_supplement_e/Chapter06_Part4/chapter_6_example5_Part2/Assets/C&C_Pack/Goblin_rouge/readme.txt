Goblin-bandit readme.

Controls:

to change the combat and normal mode press 1 or 2
(most actions available in combat mode)

moving - directional arrows
attack1 - mouse 1
attack2 - mouse 2
powerattack - m
cast - mouse 3
jump - space
defence - p
hit - u
die1 - i
die2 - o

I hope you will enjoy =)
Kind regards, GrigoriyArx